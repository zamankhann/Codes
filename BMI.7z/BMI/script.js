function calculateBMI() {
  var weight = document.getElementById('weight').value;
  var height = document.getElementById('height').value;

  if (weight === '' || height === '') {
    document.getElementById('result').innerText = 'Please enter both weight and height.';
    return;
  }

  var bmi = weight / ((height / 100) * (height / 100));
  bmi = bmi.toFixed(2);

  var resultText = 'Your BMI is ' + bmi + ', which means you are ';
  if (bmi < 18.5) {
    var normalWeight = ((height / 100) * (height / 100)) * 18.5;
    var weightDifference = (normalWeight - weight).toFixed(2);
    resultText += 'underweight. To reach the normal weight range, you need to gain approximately ' + weightDifference + ' kg.';

    var caloriesToGain = (weightDifference * 7700).toFixed(0); // Approximate 7700 calories in 1 kg
    resultText += ' This corresponds to an approximate calorie intake of ' + caloriesToGain + ' calories.';
  } else if (bmi >= 18.5 && bmi < 24.9) {
    resultText += 'in the normal weight range. You are already at a healthy weight.';
  } else {
    var normalWeight = ((height / 100) * (height / 100)) * 24.9;
    var weightDifference = (weight - normalWeight).toFixed(2);
    resultText += 'overweight. To reach the normal weight range, you need to reduce approximately ' + weightDifference + ' kg.';

    var caloriesToLose = (weightDifference * 7700).toFixed(0); // Approximate 7700 calories in 1 kg
    resultText += ' This corresponds to an approximate calorie deficit of ' + caloriesToLose + ' calories.';
  }

  var caloriesBurnedPerStep = 0.05; // Approximate average calories burned per step
  var caloriesBurned = (caloriesBurnedPerStep * 10000).toFixed(0);
  resultText += ' Taking 10,000 steps can help burn approximately ' + caloriesBurned + ' calories.';

  document.getElementById('result').innerText = resultText;
}
